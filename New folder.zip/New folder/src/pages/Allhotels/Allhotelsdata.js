import Allhotelsimag1 from '../../images/hotel1.png';
import Allhotelsimag2 from '../../images/hotel1.png';
import Allhotelsimag3 from '../../images/hotel1.png';
import Allhotelsimag4 from '../../images/hotel1.png';
import { Allhotelsroomsprice } from './Allhotels.styled';


const Allhotelsdata = [
    
    {
        
    
        Allhotelsimg: Allhotelsimag1,
        Allhotelsname : "Old Hunza Inn",
        category:'hunza',        
        Allhotelsreview:3 ,
        Allhotelsoverview:1200,
        Allhotelstotalroom:1,
        Allhotelstotalday: 3,
        Allhotelsroomsprice:100 ,
        Allhotelsroomstextfree:'Includes taxes and fees' ,
        Allhotelsdisc:'Lorem ipsum dolor sit amet consectetur. Vitae malesuada massa auctor mi morbi arcu lobortis gravida. Massa sit mauris etiam fames a ut. Ligula odio et interdum mi.' ,
    
        
    },  
    {
        
    
        Allhotelsimg: Allhotelsimag1,
        Allhotelsname : "Old Hunza Inn",
        category:'hunza',        
        Allhotelsreview:5 ,
        Allhotelstotalroom:1,
        Allhotelstotalday: 3,
        Allhotelsroomsprice:100 ,
        Allhotelsroomstextfree:'Includes taxes and fees' ,
        Allhotelsdisc:'Lorem ipsum dolor sit amet consectetur. Vitae malesuada massa auctor mi morbi arcu lobortis gravida. Massa sit mauris etiam fames a ut. Ligula odio et interdum mi.' ,
    
        
    },  
    {
        
    
        Allhotelsimg: Allhotelsimag1,
        Allhotelsname : "Old Hunza Inn",
        category:'hunza',        
        Allhotelsreview:2 ,
        Allhotelstotalroom:1,
        Allhotelstotalday: 3,
        Allhotelsroomsprice:100 ,
        Allhotelsroomstextfree:'Includes taxes and fees' ,
        Allhotelsdisc:'Lorem ipsum dolor sit amet consectetur. Vitae malesuada massa auctor mi morbi arcu lobortis gravida. Massa sit mauris etiam fames a ut. Ligula odio et interdum mi.' ,
    
        
    },  
    {
        
    
        Allhotelsimg: Allhotelsimag1,
        Allhotelsname : "Old Hunza Inn",
        category:'hunza',        
        Allhotelsreview:4 ,
        Allhotelstotalroom:1,
        Allhotelstotalday: 3,
        Allhotelsroomsprice:100 ,
        Allhotelsroomstextfree:'Includes taxes and fees' ,
        Allhotelsdisc:'Lorem ipsum dolor sit amet consectetur. Vitae malesuada massa auctor mi morbi arcu lobortis gravida. Massa sit mauris etiam fames a ut. Ligula odio et interdum mi.' ,
    
        
    },  
    {
        
    
        Allhotelsimg: Allhotelsimag1,
        Allhotelsname : "Old Hunza Inn",
        category:'hunza',        
        Allhotelsreview:3 ,
        Allhotelstotalroom:1,
        Allhotelstotalday: 3,
        Allhotelsroomsprice:100 ,
        Allhotelsroomstextfree:'Includes taxes and fees' ,
        Allhotelsdisc:'Lorem ipsum dolor sit amet consectetur. Vitae malesuada massa auctor mi morbi arcu lobortis gravida. Massa sit mauris etiam fames a ut. Ligula odio et interdum mi.' ,
    
        
    },  
]
export default Allhotelsdata