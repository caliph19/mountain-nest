import hotelimg1 from '../../../images/hotel1.png'
import hotelimg2 from '../../../images/hotel2.png'
import hotelimg3 from '../../../images/hotel3.png'




const Hoteldetais1 = [
    {
        
    
        Hotelname : "HUNZA PLACE",
        Hotelimg: hotelimg1,
        category:'hunza',    
        Hotelprice: 1000,    
        Hotelstay : "4 Days/3 Nights ",
    
        
    },  
    {
        
    
        Hotelname : "OLD HUNZA IN PLACE",
        Hotelimg: hotelimg2,
        category:'hunza',    
        Hotelprice: 2000,    
        Hotelstay : "6 Days/5 Nights ",
    
        
    }, 
    {
        
    
        Hotelname : "AMBIANCE RESORT PLACE",
        Hotelimg: hotelimg3,
        category:'hunza',    
        Hotelprice: 3000,    
        Hotelstay : "7 Days/6 Nights ",

    
        
    }, 
]

export default Hoteldetais1